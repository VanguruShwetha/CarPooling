package DBMS;
//import java.io.*;
import java.sql.*;
public class CreateTables 
{
	public static void main(String[] args)throws Exception
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Shwetha","vasavi");
		Statement st=con.createStatement();
		
		//Queries for creating tables
		
		String sql="create table menu(dishid number,dishname varchar2(20),dishprice number,dishtype varchar2(10))";
		//String sql="create table restaurant(restaurantid number,restaurantname varchar2(20),restaurantprice number,restauranttype varchar2(10))";
		//String sql= "Create table States(state_Id number,state_Name varchar(30),package varchar(30),days integer)";
		//String sql="create table orders(orderid number,ordername varchar2(20),orderprice number,ordertype varchar2(10))";
		st.executeUpdate(sql);
		System.out.println("Table created successfully");
		con.close();
	}
}
