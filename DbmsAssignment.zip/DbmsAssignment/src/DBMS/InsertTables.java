package DBMS;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
@SuppressWarnings("serial")
public class InsertTables extends Frame implements ActionListener
{
	MenuBar mb;
	MenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m19;
	Menu owner,customer,pool,arranges,registered;
	Button insertButton,submit;
	TextField owner_idText, nameText, ageText, mobile_numberText, genderText, addressText;
	TextField customer_idText, NameText,AgeText,Mobile_NumberText, GenderText,AddressText;
	TextField pool_idText, start_pText, endText, dayText, timingText;
	TextField Owner_idText,Pool_idText;
	TextField Customer_IdText,Pool_IdText,locationText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	Button modify;
	List ownerList,customerList,poolList,arrangesList,registeredList;
	ResultSet rs;
	Button deleteRowButton;
	public InsertTables()
	{
		try 
		{
			Class.forName ("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB ();
	}
	public void connectToDB() 
    {
		try 
		{
		  connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Shwetha","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildFrame()
	{
		//Basic Frame Properties
		setTitle("Car Pooling");
		setSize(500, 600);
		setVisible(true);
		
		//menubar
		mb = new MenuBar();
		setMenuBar(mb);  
        setSize(550,500);  
        setLayout(null);  
        setVisible(true);
        owner=new Menu("Owner");
        m1=new MenuItem("Insert Owner");  
        m2=new MenuItem("Update Owner");  
        m3=new MenuItem("Delete Owner");  
        m4=new MenuItem("View Owner");
        owner.add(m1);  
        owner.add(m2);  
        owner.add(m3); 
        owner.add(m4);
        mb.add(owner);
        customer=new Menu("Customer"); 
        m5=new MenuItem("Insert Customer");
        m6=new MenuItem("Update Customer");
        m7=new MenuItem("Delete Customer");
        m8=new MenuItem("View Customer");
        customer.add(m5);  
        customer.add(m6);  
        customer.add(m7); 
        customer.add(m8);
        mb.add(customer);
        pool=new Menu("Pool");
        m9=new MenuItem("Insert Pool");
        m10=new MenuItem("Update Pool");
        m11=new MenuItem("Delete Pool");
        m12=new MenuItem("View Pool");
        pool.add(m9);  
        pool.add(m10);  
        pool.add(m11); 
        pool.add(m12);
        mb.add(pool);
        arranges=new Menu("Arranges");
        m13=new MenuItem("Insert Arranges");
        m14=new MenuItem("Delete Arranges");
        m15=new MenuItem("View Arranges");
        arranges.add(m13);
        arranges.add(m14);
        arranges.add(m15);
        mb.add(arranges);
        registered=new Menu("Registered");
        m16=new MenuItem("Insert Registerd");
        m17=new MenuItem("Update Registered");
        m18=new MenuItem("Delete Registered");
        m19=new MenuItem("View Registered");
        registered.add(m16);
        registered.add(m17);
        registered.add(m18);
        registered.add(m19);
        mb.add(registered);
        m1.addActionListener(this);
        m2.addActionListener(this);
        m3.addActionListener(this);
        m4.addActionListener(this);
        m5.addActionListener(this);
        m6.addActionListener(this);
        m7.addActionListener(this);
        m8.addActionListener(this);
        m9.addActionListener(this);
        m10.addActionListener(this);
        m11.addActionListener(this);
        m12.addActionListener(this);
        m13.addActionListener(this);
        m14.addActionListener(this);
        m15.addActionListener(this);
        m16.addActionListener(this);
        m17.addActionListener(this);
        m18.addActionListener(this);
        m19.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String arg = ae.getActionCommand();
		if(arg.equals("Insert Owner"))
			this.buildGUIOwner();
		if(arg.equals("Update Owner"))
			this.updateGUIOwner();
		if(arg.equals("Delete Owner"))
			this.deleteGUIOwner();
		if(arg.equals("View Owner"))
			this.viewGUIOwner();
		if(arg.equals("Insert Customer"))
			this.buildGUICustomer();
		if(arg.equals("Update Customer "))
			this.updateGUICustomer();
		if(arg.equals("Delete Customer"))
			this.deleteGUICustomer();
		if(arg.equals("View Customer"))
			this.viewGUICustomer();
		if(arg.equals("Insert Pool"))
			this.buildGUIPool();
		if(arg.equals("Update Pool"))
			this.updateGUIPool();
		if(arg.equals("Delete Pool"))
			this.deleteGUIPool();
		if(arg.equals("View Pool"))
			this.viewGUIPool();
		if(arg.equals("Insert Arranges"))
			this.buildGUIArranges();
		if(arg.equals("Delete Arranges"))
			this.deleteGUIArranges();
		if(arg.equals("View Arranges"))
			this.viewGUIArranges();	
		if(arg.equals("Insert Registered"))
			this.buildGUIRegistered();
		if(arg.equals("Delete Registered"))
			this.deleteGUIRegistered();
		if(arg.equals("Update Registered"))
			this.updateGUIRegistered();
		if(arg.equals("View Registered"))
			this.viewGUIRegistered();	
	}
	public void buildGUIOwner() 
	{	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO owner VALUES('"+ owner_idText.getText() + "', " + "'" + nameText.getText() + "'," + "'"+ ageText.getText() + "'," + "'"+ mobile_numberText.getText() + "',"+ "'" + genderText.getText() + "',"+ "'" + addressText.getText() + "'"+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		owner_idText = new TextField(15);
		nameText = new TextField(15);
		ageText = new TextField(15);
		mobile_numberText= new TextField(15);
		genderText = new TextField(15);
		addressText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(owner_idText);
		first.add(new Label("Owner Name:"));
		first.add(nameText);
		first.add(new Label("Age:"));
		first.add(ageText);
		first.add(new Label("Mobile_Number"));
		first.add(mobile_numberText);
		first.add(new Label("Gender:"));
		first.add(genderText);
		first.add(new Label("Address:"));
		first.add(addressText);
		first.setBounds(125,90,200,100);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		add(first);
		add(second);
		add(third);setLayout(new FlowLayout());
		setVisible(true);
	}
	public void buildGUICustomer() 
	{	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO customer VALUES('"+ customer_idText.getText() + "', " + "'" + NameText.getText() + "'," + "'"+ AgeText.getText() + "'," + "'"+ Mobile_NumberText.getText() + "',"+ "'" + GenderText.getText() + "',"+ "'" + AddressText.getText() + "'"+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		customer_idText = new TextField(15);
		NameText = new TextField(15);
		AgeText = new TextField(15);
		Mobile_NumberText= new TextField(15);
		GenderText = new TextField(15);
		AddressText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(customer_idText);
		first.add(new Label("Customer Name:"));
		first.add(NameText);
		first.add(new Label("Age:"));
		first.add(AgeText);
		first.add(new Label("Mobile_Number"));
		first.add(Mobile_NumberText);
		first.add(new Label("Gender:"));
		first.add(GenderText);
		first.add(new Label("Address:"));
		first.add(AddressText);
		first.setBounds(125,90,200,100);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		add(first);
		add(second);
		add(third);setLayout(new FlowLayout());
		setVisible(true);
	}
	public void buildGUIPool() 
	{	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO pool VALUES('"+ pool_idText.getText() + "', " + "'" + start_pText.getText() + "'," + "'"+ endText.getText() + "'," + "'"+ dayText.getText() + "',"+ "'" + timingText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		pool_idText = new TextField(15);
		start_pText = new TextField(15);
		endText = new TextField(15);
		dayText= new TextField(15);
		timingText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Pool ID:"));
		first.add(pool_idText);
		first.add(new Label("Start Point:"));
		first.add(start_pText);
		first.add(new Label("End Point:"));
		first.add(endText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Timings:"));
		first.add(timingText);
		first.setBounds(125,90,200,100);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		add(first);
		add(second);
		add(third);setLayout(new FlowLayout());
		setVisible(true);
	}
	public void buildGUIArranges() 
	{	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO arranges VALUES('"+ Owner_idText.getText() + "', '"+Pool_idText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		Owner_idText = new TextField(15);
		Pool_idText=new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(Owner_idText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_idText);
		first.setBounds(125,90,200,100);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		add(first);
		add(second);
		add(third);setLayout(new FlowLayout());
		setVisible(true);
	}
	public void buildGUIRegistered() 
	{	
		removeAll();
		registeredList = new List(6);
		loadRegistered();
		add(registeredList);
		
		//When a list item is selected populate the text fields
		registeredList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM registered");
					while (rs.next()) 
					{
						if (rs.getString("customer_id").equals(registeredList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Customer_IdText.setText(rs.getString("customer_id"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO registered VALUES('"+ Customer_IdText.getText() + "', '"+Pool_IdText.getText() +"', '"+locationText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		Customer_IdText = new TextField(15);
		Customer_IdText.setEditable(false);
		Pool_IdText=new TextField(15);
		locationText=new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(Customer_IdText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_IdText);
		first.add(new Label("Location:"));
		first.add(locationText);
		first.setBounds(125,90,200,100);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		add(first);
		add(second);
		add(third);
		setLayout(new FlowLayout());
		setVisible(true);
	}
	private void loadMenu() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM owner");
		  while (rs.next()) 
		  {
			  ownerList.add(rs.getString("owner_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateGUIOwner()
	{	
		removeAll();
		ownerList = new List(6);
		loadMenu();
		add(ownerList);
		ownerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM owner");
					while (rs.next()) 
					{
						if (rs.getString("owner_id").equals(ownerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						owner_idText.setText(rs.getString("owner_id"));
						nameText.setText(rs.getString("name"));
						ageText.setText(rs.getString("age"));
						mobile_numberText.setText(rs.getString("mobile_number"));
						genderText.setText(rs.getString("gender"));
						addressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE owner "
					+ "SET name=" +"'"+ nameText.getText() +"',"+"gender='"+genderText.getText()+"',"+"mobile_number='"+mobile_numberText.getText()+"',"+"age='"+ageText.getText()+"',"+"address='"+addressText.getText()+"'"
					+ " WHERE owner_id = '" + ownerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					ownerList.removeAll();
					loadMenu();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		owner_idText = new TextField(15);
		owner_idText.setEditable(false);
		nameText = new TextField(15);
		ageText = new TextField(15);
		//ageText.setEditable(false);
		mobile_numberText = new TextField(15);
		//mobile_numberText.setEditable(false);
		genderText = new TextField(15);
		//genderText.setEditable(false);
		addressText = new TextField(15);
		//addressText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(owner_idText);
		first.add(new Label("Name:"));
		first.add(nameText);
		first.add(new Label("Age"));
		first.add(ageText);
		first.add(new Label("Mobile Number:"));
		first.add(mobile_numberText);
		first.add(new Label("Gender:"));
		first.add(genderText);
		first.add(new Label("Address:"));
		first.add(addressText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);	
	}
	public void deleteGUIOwner()
	{	
		removeAll();
		ownerList = new List(10);
		loadMenu();
		add(ownerList);
			
		//When a list item is selected populate the text fields
		ownerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM owner");
					while (rs.next()) 
					{
						if (rs.getString("owner_id").equals(ownerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						owner_idText.setText(rs.getString("owner_id"));
						nameText.setText(rs.getString("name"));
						ageText.setText(rs.getString("age"));
						mobile_numberText.setText(rs.getString("mobile_number"));
						genderText.setText(rs.getString("gender"));
						addressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM owner WHERE owner_id = '" + ownerList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					owner_idText.setText(null);
					nameText.setText(null);
					ageText.setText(null);
					mobile_numberText.setText(null);
					genderText.setText(null);
					addressText.setText(null);
					ownerList.removeAll();
					loadMenu();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		owner_idText = new TextField(15);
		nameText = new TextField(15);
		ageText = new TextField(15);
		mobile_numberText = new TextField(15);
		genderText = new TextField(15);
		addressText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		owner_idText.setEditable(false);
		nameText.setEditable(false);
		ageText.setEditable(false);
		mobile_numberText.setEditable(false);
		genderText.setEditable(false);
		addressText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(owner_idText);
		first.add(new Label("Name:"));
		first.add(nameText);
		first.add(new Label("Age:"));
		first.add(ageText);
		first.add(new Label("Mobile Number:"));
		first.add(mobile_numberText);
		first.add(new Label("Gender:"));
		first.add(genderText);
		first.add(new Label("Address:"));
		first.add(addressText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewGUIOwner() 
	{	
		removeAll();
		ownerList = new List(6);
		loadMenu();
		add(ownerList);
		
		//When a list item is selected populate the text fields
		ownerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM owner");
					while (rs.next()) 
					{
						if (rs.getString("owner_id").equals(ownerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						owner_idText.setText(rs.getString("owner_id"));
						nameText.setText(rs.getString("name"));
						ageText.setText(rs.getString("age"));
						mobile_numberText.setText(rs.getString("mobile_number"));
						genderText.setText(rs.getString("gender"));
						addressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Owner");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE owner "
					+ "SET name=" + nameText.getText()  
					+ " WHERE owner_id = '" + ownerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					ownerList.removeAll();
					loadMenu();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		owner_idText = new TextField(15);
		owner_idText.setEditable(false);
		nameText = new TextField(15);
		nameText.setEditable(false);
		ageText = new TextField(15);
		ageText.setEditable(false);
		mobile_numberText = new TextField(15);
		mobile_numberText.setEditable(false);
		genderText = new TextField(15);
		genderText.setEditable(false);
		addressText = new TextField(15);
		addressText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(owner_idText);
		first.add(new Label("Name:"));
		first.add(nameText);
		first.add(new Label("Age:"));
		first.add(ageText);
		first.add(new Label("Mobile Number:"));
		first.add(mobile_numberText);
		first.add(new Label("Gender:"));
		first.add(genderText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	private void loadCustomer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM customer");
		  while (rs.next()) 
		  {
			  customerList.add(rs.getString("customer_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateGUICustomer()
	{	
		removeAll();
		customerList = new List(6);
		loadCustomer();
		add(customerList);
		customerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer");
					while (rs.next()) 
					{
						if (rs.getString("customer_id").equals(customerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						customer_idText.setText(rs.getString("customer_id"));
						NameText.setText(rs.getString("name"));
						AgeText.setText(rs.getString("age"));
						Mobile_NumberText.setText(rs.getString("mobile_number"));
						GenderText.setText(rs.getString("gender"));
						AddressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE customer "
					+ "SET name=" +"'"+ NameText.getText() +"',"+"gender='"+GenderText.getText()+"',"+"mobile_number='"+Mobile_NumberText.getText()+"',"+"age='"+AgeText.getText()+"',"+"address='"+AddressText.getText()+"'"
					+ " WHERE customer_id = '" + customerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					customerList.removeAll();
					loadCustomer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		customer_idText = new TextField(15);
		customer_idText.setEditable(false);
		NameText = new TextField(15);
		AgeText = new TextField(15);
		//ageText.setEditable(false);
		Mobile_NumberText = new TextField(15);
		//mobile_numberText.setEditable(false);
		GenderText = new TextField(15);
		//genderText.setEditable(false);
		AddressText = new TextField(15);
		//addressText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(customer_idText);
		first.add(new Label("Name:"));
		first.add(NameText);
		first.add(new Label("Age"));
		first.add(AgeText);
		first.add(new Label("Mobile Number:"));
		first.add(Mobile_NumberText);
		first.add(new Label("Gender:"));
		first.add(GenderText);
		first.add(new Label("Address:"));
		first.add(AddressText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);	
	}
	public void deleteGUICustomer()
	{	
		removeAll();
		customerList = new List(10);
		loadCustomer();
		add(customerList);
			
		//When a list item is selected populate the text fields
		customerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer");
					while (rs.next()) 
					{
						if (rs.getString("customer_id").equals(customerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						customer_idText.setText(rs.getString("customer_id"));
						NameText.setText(rs.getString("name"));
						AgeText.setText(rs.getString("age"));
						Mobile_NumberText.setText(rs.getString("mobile_number"));
						GenderText.setText(rs.getString("gender"));
						AddressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM customer WHERE customer_id = '" + customerList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					customer_idText.setText(null);
					NameText.setText(null);
					AgeText.setText(null);
					Mobile_NumberText.setText(null);
					GenderText.setText(null);
					AddressText.setText(null);
					customerList.removeAll();
					loadCustomer();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		customer_idText = new TextField(15);
		NameText = new TextField(15);
		AgeText = new TextField(15);
		Mobile_NumberText = new TextField(15);
		GenderText = new TextField(15);
		AddressText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		customer_idText.setEditable(false);
		NameText.setEditable(false);
		AgeText.setEditable(false);
		Mobile_NumberText.setEditable(false);
		GenderText.setEditable(false);
		AddressText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(customer_idText);
		first.add(new Label("Name:"));
		first.add(NameText);
		first.add(new Label("Age:"));
		first.add(AgeText);
		first.add(new Label("Mobile Number:"));
		first.add(Mobile_NumberText);
		first.add(new Label("Gender:"));
		first.add(GenderText);
		first.add(new Label("Address:"));
		first.add(AddressText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewGUICustomer() 
	{	
		removeAll();
		customerList = new List(6);
		loadCustomer();
		add(customerList);
		
		//When a list item is selected populate the text fields
		customerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer");
					while (rs.next()) 
					{
						if (rs.getString("customer_id").equals(customerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						customer_idText.setText(rs.getString("customer_id"));
						NameText.setText(rs.getString("name"));
						AgeText.setText(rs.getString("age"));
						Mobile_NumberText.setText(rs.getString("mobile_number"));
						GenderText.setText(rs.getString("gender"));
						AddressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Customer");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE customer "
					+ "SET name=" + nameText.getText()  
					+ " WHERE customer_id = '" + customerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					customerList.removeAll();
					loadCustomer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		customer_idText = new TextField(15);
		customer_idText.setEditable(false);
		NameText = new TextField(15);
		NameText.setEditable(false);
		AgeText = new TextField(15);
		AgeText.setEditable(false);
		Mobile_NumberText = new TextField(15);
		Mobile_NumberText.setEditable(false);
		GenderText = new TextField(15);
		GenderText.setEditable(false);
		AddressText = new TextField(15);
		AddressText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(customer_idText);
		first.add(new Label("Name:"));
		first.add(NameText);
		first.add(new Label("Age:"));
		first.add(AgeText);
		first.add(new Label("Mobile Number:"));
		first.add(Mobile_NumberText);
		first.add(new Label("Gender:"));
		first.add(GenderText);
		first.add(new Label("Address:"));
		first.add(AddressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	private void loadPool() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM pool");
		  while (rs.next()) 
		  {
			  poolList.add(rs.getString("pool_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateGUIPool()
	{	
		removeAll();
		poolList = new List(6);
		loadPool();
		add(poolList);
		poolList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM pool");
					while (rs.next()) 
					{
						if (rs.getString("pool_id").equals(poolList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						pool_idText.setText(rs.getString("pool_id"));
						start_pText.setText(rs.getString("start_p"));
						endText.setText(rs.getString("end"));
						dayText.setText(rs.getString("day"));
						timingText.setText(rs.getString("timing"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE pool "
					+ "SET start_p=" +"'"+ start_pText.getText() +"',"+"end='"+endText.getText()+"',"+"day='"+dayText.getText()+"',"+"timing='"+timingText.getText()+"'"
					+ " WHERE pool_id = '" + poolList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					poolList.removeAll();
					loadPool();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		pool_idText = new TextField(15);
		pool_idText.setEditable(false);
		start_pText = new TextField(15);
		endText = new TextField(15);
		//ageText.setEditable(false);
		dayText = new TextField(15);
		//mobile_numberText.setEditable(false);
		timingText = new TextField(15);
		//genderText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Pool ID:"));
		first.add(pool_idText);
		first.add(new Label("Start Point:"));
		first.add(start_pText);
		first.add(new Label("End Point"));
		first.add(endText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Timings:"));
		first.add(timingText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);	
	}
	public void deleteGUIPool()
	{	
		removeAll();
		poolList = new List(10);
		loadPool();
		add(poolList);
			
		//When a list item is selected populate the text fields
		poolList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM pool");
					while (rs.next()) 
					{
						if (rs.getString("pool_id").equals(poolList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						pool_idText.setText(rs.getString("pool_id"));
						start_pText.setText(rs.getString("start_p"));
						endText.setText(rs.getString("end"));
						dayText.setText(rs.getString("day"));
						timingText.setText(rs.getString("timing"));
						//addressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM pool WHERE pool_id = '" + poolList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					pool_idText.setText(null);
					start_pText.setText(null);
					endText.setText(null);
					dayText.setText(null);
					timingText.setText(null);
					poolList.removeAll();
					loadPool();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		pool_idText = new TextField(15);
		start_pText = new TextField(15);
		endText = new TextField(15);
		dayText = new TextField(15);
		timingText = new TextField(15);
		//addressText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		pool_idText.setEditable(false);
		start_pText.setEditable(false);
		endText.setEditable(false);
		dayText.setEditable(false);
		timingText.setEditable(false);
		//addressText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Pool ID:"));
		first.add(pool_idText);
		first.add(new Label("Starting Point:"));
		first.add(start_pText);
		first.add(new Label("End Point:"));
		first.add(endText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Timings:"));
		first.add(timingText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewGUIPool() 
	{	
		removeAll();
		poolList = new List(6);
		loadPool();
		add(poolList);
		
		//When a list item is selected populate the text fields
		poolList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM pool");
					while (rs.next()) 
					{
						if (rs.getString("pool_id").equals(poolList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						pool_idText.setText(rs.getString("pool_id"));
						start_pText.setText(rs.getString("start_p"));
						endText.setText(rs.getString("end"));
						dayText.setText(rs.getString("day"));
						timingText.setText(rs.getString("timing"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Pool");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE pool "
					+ "SET start_p=" + start_pText.getText()  
					+ " WHERE pool_id = '" + poolList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					poolList.removeAll();
					loadPool();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		pool_idText = new TextField(15);
		pool_idText.setEditable(false);
		start_pText = new TextField(15);
		start_pText.setEditable(false);
		endText = new TextField(15);
		endText.setEditable(false);
		dayText = new TextField(15);
		dayText.setEditable(false);
		timingText = new TextField(15);
		timingText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Pool ID:"));
		first.add(pool_idText);
		first.add(new Label("Starting Point:"));
		first.add(start_pText);
		first.add(new Label("End Point:"));
		first.add(endText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Timings:"));
		first.add(timingText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	private void loadArranges() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM arranges");
		  while (rs.next()) 
		  {
			  arrangesList.add(rs.getString("Owner_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void deleteGUIArranges()
	{	
		removeAll();
		arrangesList = new List(10);
		loadArranges();
		add(arrangesList);
			
		//When a list item is selected populate the text fields
		arrangesList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM arranges");
					while (rs.next()) 
					{
						if (rs.getString("Owner_id").equals(arrangesList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Owner_idText.setText(rs.getString("Owner_id"));
						Pool_idText.setText(rs.getString("Pool_id"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM arranges WHERE Owner_id = '" + arrangesList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					Owner_idText.setText(null);
					Pool_idText.setText(null);
					arrangesList.removeAll();
					loadArranges();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		Owner_idText = new TextField(15);
		Pool_idText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Owner_idText.setEditable(false);
		Pool_idText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(Owner_idText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_idText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewGUIArranges() 
	{	
		removeAll();
		arrangesList = new List(6);
		loadArranges();
		add(arrangesList);
		
		//When a list item is selected populate the text fields
		arrangesList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM arranges");
					while (rs.next()) 
					{
						if (rs.getString("Owner_id").equals(arrangesList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Owner_idText.setText(rs.getString("Owner_id"));
						Pool_idText.setText(rs.getString("pool_id"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		/*modify = new Button("Update Arranges");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE arranges "
					+ "SET name=" + nameText.getText()  
					+ " WHERE owner_id = '" + ownerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					ownerList.removeAll();
					loadMenu();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});*/
		Owner_idText = new TextField(15);
		Owner_idText.setEditable(false);
		Pool_idText = new TextField(15);
		Pool_idText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Owner ID:"));
		first.add(Owner_idText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_idText);
	
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	private void loadRegistered() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM registered");
		  while (rs.next()) 
		  {
			  registeredList.add(rs.getString("customer_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateGUIRegistered()
	{	
		removeAll();
		registeredList = new List(6);
		loadRegistered();
		add(registeredList);
		registeredList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM registered");
					while (rs.next()) 
					{
						if (rs.getString("Customer_Id").equals(registeredList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Customer_IdText.setText(rs.getString("Customer_Id"));
						Pool_IdText.setText(rs.getString("Pool_Id"));
						locationText.setText(rs.getString("location"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE registered "
					+ "SET location=" +"'"+ locationText.getText() +"'"
					+ " WHERE Customer_Id = '" + registeredList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					registeredList.removeAll();
					loadRegistered();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		Customer_IdText = new TextField(15);
		Customer_IdText.setEditable(false);
		Pool_IdText = new TextField(15);
		Pool_IdText.setEditable(false);
		locationText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(Customer_IdText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_IdText);
		first.add(new Label("Location"));
		first.add(locationText);
	
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);	
	}
	public void deleteGUIRegistered()
	{	
		removeAll();
		registeredList = new List(10);
		loadRegistered();
		add(registeredList);
			
		//When a list item is selected populate the text fields
		registeredList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM registered");
					while (rs.next()) 
					{
						if (rs.getString("Customer_Id").equals(registeredList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Customer_IdText.setText(rs.getString("customer_id"));
						Pool_IdText.setText(rs.getString("Pool_id"));
						locationText.setText(rs.getString("location"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM registered WHERE Customer_id = '" + registeredList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					Customer_IdText.setText(null);
					Pool_IdText.setText(null);
					locationText.setText(null);
					registeredList.removeAll();
					loadRegistered();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		Customer_IdText = new TextField(15);
		Pool_IdText = new TextField(15);
		locationText = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Customer_IdText.setEditable(false);
		Pool_IdText.setEditable(false);
		locationText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(Customer_IdText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_IdText);
		first.add(new Label("Location:"));
		first.add(locationText);
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewGUIRegistered() 
	{	
		removeAll();
		registeredList = new List(6);
		loadRegistered();
		add(registeredList);
		
		//When a list item is selected populate the text fields
		registeredList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM registered");
					while (rs.next()) 
					{
						if (rs.getString("customer_id").equals(registeredList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						Customer_IdText.setText(rs.getString("Customer_id"));
						Pool_IdText.setText(rs.getString("pool_id"));
						locationText.setText(rs.getString("location"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Registered");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE registered "
					+ "SET location=" + locationText.getText()  
					+ " WHERE Customer_Id = '" + registeredList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					registeredList.removeAll();
					loadRegistered();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		Customer_IdText = new TextField(15);
		Customer_IdText.setEditable(false);
		Pool_IdText = new TextField(15);
		Pool_IdText.setEditable(false);
		locationText = new TextField(15);
		locationText.setEditable(false);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(Customer_IdText);
		first.add(new Label("Pool ID:"));
		first.add(Pool_IdText);
		first.add(new Label("Location:"));
		first.add(locationText);
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		//setTitle("Update ....");
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		InsertTables it = new InsertTables();
		it.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		it.buildFrame();
	}
}	
